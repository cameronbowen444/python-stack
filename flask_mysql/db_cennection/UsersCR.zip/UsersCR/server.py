from flask import Flask, render_template, request, redirect
from user import User

app = Flask(__name__)

@app.route('/')
def index():
    users = User.get_users()
    print(users)
    return render_template('create.html',users=users)


@app.route('/create_user', methods=["POST"])
def create():
    data = {
        "first_name" : request.form["first_name"],
        "last_name" : request.form["last_name"],
        "email" : request.form["email"]
    }
    User.add_users(data)
    return redirect('/read')


@app.route('/read')
def read():
    users = User.get_users()
    print(users)
    return render_template('read.html', users=users)


if __name__=="__main__":
    app.run(debug=True)